import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

const kPri = Color(0xFF4F46E5);
const kPri2 = Color(0xFF7C3AED);
const kBg = Color(0xFFF4F5FA);
const kMute = Color(0xFF677089);
const kBorder = Color(0xFFE3E6F1);
const kChip = Color(0xFFEEF0FB);
const kOk = Color(0xFF0F9D58);

void main() => runApp(const ResnapApp());

class ResnapApp extends StatelessWidget {
  const ResnapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Resnap',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: kPri,
          useMaterial3: true,
          scaffoldBackgroundColor: kBg,
        ),
        home: const HomePage(),
      );
}

enum Mode { custom, target, percent, preset }

enum Fmt { jpg, png, webp, pdf }

enum Fit { crop, fit, stretch }

const presets = <String, Map<String, List<int>>>{
  'Social': {
    'Instagram Post 1080x1080': [1080, 1080],
    'Instagram Portrait 1080x1350': [1080, 1350],
    'Story / Reel / TikTok 1080x1920': [1080, 1920],
    'YouTube Thumbnail 1280x720': [1280, 720],
    'YouTube Banner 2560x1440': [2560, 1440],
    'Facebook Cover 820x312': [820, 312],
    'Facebook Post 1200x630': [1200, 630],
    'X / Twitter Post 1600x900': [1600, 900],
    'X Header 1500x500': [1500, 500],
    'LinkedIn Banner 1584x396': [1584, 396],
    'LinkedIn Profile 400x400': [400, 400],
    'WhatsApp Profile 500x500': [500, 500],
    'Pinterest Pin 1000x1500': [1000, 1500],
  },
  'ID & Documents': {
    'Passport 35x45 mm (413x531)': [413, 531],
    'Passport / Visa 2x2 in (600x600)': [600, 600],
    'Passport 33x48 mm (390x567)': [390, 567],
    'Stamp size 20x25 mm (236x295)': [236, 295],
    'A4 at 150 dpi (1240x1754)': [1240, 1754],
    'Signature 140x60': [140, 60],
  },
  'Screens': {
    'Full HD 1920x1080': [1920, 1080],
    'HD 1280x720': [1280, 720],
    'Wallpaper 1080x2400': [1080, 2400],
    'Website banner 1200x400': [1200, 400],
    'Thumbnail 300x300': [300, 300],
    'Icon 512x512': [512, 512],
  },
};

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final picker = ImagePicker();
  final scroll = ScrollController();
  final wCtrl = TextEditingController();
  final hCtrl = TextEditingController();
  final kbCtrl = TextEditingController(text: '100');

  img.Image? orig;
  int origBytes = 0;
  Uint8List? preview;
  Uint8List? result;
  int resW = 0, resH = 0;
  int baseW = 0, baseH = 0;
  bool busy = false;

  int rot = 0;
  bool flipped = false;
  Mode mode = Mode.custom;
  Fmt fmt = Fmt.jpg;
  Fit fit = Fit.stretch;
  bool lock = true;
  bool blackBg = false;
  double percent = 50;
  double quality = 85;
  String preset = 'Instagram Post 1080x1080';

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  img.Image _base() {
    var b = orig!;
    if (rot != 0) b = img.copyRotate(b, angle: rot);
    if (flipped) b = img.flip(b, direction: img.FlipDirection.horizontal);
    return b;
  }

  Uint8List _previewOf(img.Image b) {
    final s = b.width >= b.height
        ? img.copyResize(b, width: min(800, b.width))
        : img.copyResize(b, height: min(800, b.height));
    return Uint8List.fromList(img.encodeJpg(s, quality: 80));
  }

  void _refresh() {
    final b = _base();
    baseW = b.width;
    baseH = b.height;
    setState(() {
      preview = _previewOf(b);
      wCtrl.text = '${b.width}';
      hCtrl.text = '${b.height}';
      result = null;
    });
  }

  Future<void> pick() async {
    final f = await picker.pickImage(source: ImageSource.gallery);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    final d = img.decodeImage(bytes);
    if (d == null) {
      _msg('Could not open this image.');
      return;
    }
    orig = img.bakeOrientation(d);
    origBytes = bytes.length;
    rot = 0;
    flipped = false;
    _refresh();
  }

  void reset() => setState(() {
        orig = null;
        preview = null;
        result = null;
      });

  void _onW(String v) {
    if (!lock || orig == null) return;
    final w = int.tryParse(v);
    if (w == null) return;
    hCtrl.text = '${(w * baseH / baseW).round()}';
  }

  void _onH(String v) {
    if (!lock || orig == null) return;
    final h = int.tryParse(v);
    if (h == null) return;
    wCtrl.text = '${(h * baseW / baseH).round()}';
  }

  List<int> _presetDim() {
    for (final g in presets.values) {
      if (g.containsKey(preset)) return g[preset]!;
    }
    return [1080, 1080];
  }

  img.Image _fit(img.Image b, int w, int h) {
    if (w == b.width && h == b.height) return b;
    const interp = img.Interpolation.average;
    final f = (mode == Mode.preset || mode == Mode.custom) ? fit : Fit.stretch;
    if (f == Fit.stretch) {
      return img.copyResize(b, width: w, height: h, interpolation: interp);
    }
    if (f == Fit.crop) {
      final k = max(w / b.width, h / b.height);
      final rw = max(w, (b.width * k).round());
      final rh = max(h, (b.height * k).round());
      final r = img.copyResize(b, width: rw, height: rh, interpolation: interp);
      return img.copyCrop(r,
          x: (rw - w) ~/ 2, y: (rh - h) ~/ 2, width: w, height: h);
    }
    final k = min(w / b.width, h / b.height);
    final rw = max(1, (b.width * k).round());
    final rh = max(1, (b.height * k).round());
    final r = img.copyResize(b, width: rw, height: rh, interpolation: interp);
    final c = img.Image(width: w, height: h);
    img.fill(c,
        color: blackBg ? img.ColorRgb8(0, 0, 0) : img.ColorRgb8(255, 255, 255));
    img.compositeImage(c, r, dstX: (w - rw) ~/ 2, dstY: (h - rh) ~/ 2);
    return c;
  }

  Future<Uint8List> _enc(img.Image im, int q) async {
    switch (fmt) {
      case Fmt.png:
        return Uint8List.fromList(img.encodePng(im));
      case Fmt.jpg:
        return Uint8List.fromList(img.encodeJpg(im, quality: q));
      case Fmt.webp:
        final png = Uint8List.fromList(img.encodePng(im));
        return await FlutterImageCompress.compressWithList(
          png,
          format: CompressFormat.webp,
          quality: q,
          minWidth: im.width,
          minHeight: im.height,
        );
      case Fmt.pdf:
        final jpg = Uint8List.fromList(img.encodeJpg(im, quality: q));
        final doc = pw.Document();
        final page = PdfPageFormat(im.width.toDouble(), im.height.toDouble(),
            marginAll: 0);
        doc.addPage(pw.Page(
          pageFormat: page,
          build: (_) => pw.Image(pw.MemoryImage(jpg), fit: pw.BoxFit.fill),
        ));
        return await doc.save();
    }
  }

  Future<Uint8List> _encode(img.Image im) async {
    if (mode != Mode.target) return _enc(im, quality.round());
    final limit = (int.tryParse(kbCtrl.text) ?? 100) * 1024;
    var cur = im;
    for (int i = 0; i < 12; i++) {
      int lo = 5, hi = 95;
      Uint8List? best;
      if (fmt == Fmt.png) {
        final t = await _enc(cur, 90);
        if (t.length <= limit) best = t;
      } else {
        while (lo <= hi) {
          final q = (lo + hi) ~/ 2;
          final t = await _enc(cur, q);
          if (t.length <= limit) {
            best = t;
            lo = q + 1;
          } else {
            hi = q - 1;
          }
        }
      }
      if (best != null) return best;
      final nw = (cur.width * 0.85).round();
      if (nw < 8) break;
      cur = img.copyResize(cur, width: nw);
    }
    return _enc(cur, 5);
  }

  Future<void> run() async {
    if (orig == null) {
      _msg('Pick a photo first.');
      return;
    }
    setState(() => busy = true);
    await Future.delayed(const Duration(milliseconds: 60));
    try {
      final b = _base();
      int w = b.width, h = b.height;
      if (mode == Mode.custom) {
        w = int.tryParse(wCtrl.text) ?? w;
        h = int.tryParse(hCtrl.text) ?? h;
      } else if (mode == Mode.percent) {
        w = (b.width * percent / 100).round();
        h = (b.height * percent / 100).round();
      } else if (mode == Mode.preset) {
        final p = _presetDim();
        w = p[0];
        h = p[1];
      }
      if (w < 1 || h < 1 || w > 12000 || h > 12000) throw 'bad size';
      final out = await _encode(_fit(b, w, h));
      setState(() {
        result = out;
        resW = w;
        resH = h;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) {
          scroll.animateTo(scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
        }
      });
    } catch (e) {
      _msg('Something went wrong. Try a different size.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> share() async {
    if (result == null) return;
    final dir = await getTemporaryDirectory();
    final file = File(
        '${dir.path}/resnap_${DateTime.now().millisecondsSinceEpoch}.${fmt.name}');
    await file.writeAsBytes(result!);
    await Share.shareXFiles([XFile(file.path)]);
  }

  String _size(int bytes) => bytes > 1024 * 1024
      ? '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB'
      : '${max(1, (bytes / 1024).round())} KB';

  // ---------- UI helpers ----------
  Widget _card(String badge, String title, List<Widget> kids) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kBorder),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
              radius: 11,
              backgroundColor: kPri,
              child: Text(badge,
                  style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
            const SizedBox(width: 8),
            Text(title,
                style:
                    const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          const SizedBox(height: 12),
          ...kids,
        ]),
      );

  Widget _seg<T>(Map<T, String> items, T value, void Function(T) onTap) =>
      Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
            color: kChip, borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          for (final e in items.entries)
            Expanded(
              child: GestureDetector(
                onTap: () => onTap(e.key),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: e.key == value ? Colors.white : Colors.transparent,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Text(e.value,
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: e.key == value ? Colors.black : kMute)),
                ),
              ),
            ),
        ]),
      );

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 6),
        child: Text(t, style: const TextStyle(fontSize: 13, color: kMute)),
      );

  Widget _field(TextEditingController c, String label, void Function(String)? f) =>
      Expanded(
        child: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          onChanged: f,
          decoration: InputDecoration(
            labelText: label,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      );

  Widget _tool(IconData i, String t, VoidCallback f) => Expanded(
        child: OutlinedButton.icon(
          onPressed: orig == null
              ? null
              : () {
                  f();
                  _refresh();
                },
          icon: Icon(i, size: 18),
          label: Text(t, style: const TextStyle(fontSize: 13)),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(0, 46),
            side: const BorderSide(color: kBorder),
            foregroundColor: Colors.black87,
          ),
        ),
      );

  Widget _stat(String v, String l, {Color? c}) => Expanded(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
              color: kChip, borderRadius: BorderRadius.circular(12)),
          child: Column(children: [
            Text(v,
                style: TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 16, color: c)),
            Text(l, style: const TextStyle(fontSize: 11, color: kMute)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final saved = result == null
        ? 0
        : max(0, ((1 - result!.length / origBytes) * 100).round());
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
            child: Row(children: [
              Image.asset('assets/logo.png', width: 38, height: 38),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Resnap',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w800)),
                      Text('Resize & compress photos, free',
                          style: TextStyle(fontSize: 12, color: kMute)),
                    ]),
              ),
              if (orig != null)
                TextButton(onPressed: reset, child: const Text('Reset')),
            ]),
          ),
          const Divider(height: 1, color: kBorder),
          Expanded(
            child: ListView(
              controller: scroll,
              padding: const EdgeInsets.all(14),
              children: [
                _card('1', 'Choose photo', [
                  if (orig == null)
                    InkWell(
                      onTap: pick,
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 28),
                        decoration: BoxDecoration(
                          color: kChip,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: kBorder, width: 2),
                        ),
                        child: const Column(children: [
                          Text('Tap to pick a photo',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w700)),
                          SizedBox(height: 4),
                          Text('Stays on your device',
                              style: TextStyle(color: kMute, fontSize: 13)),
                        ]),
                      ),
                    )
                  else ...[
                    if (preview != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(preview!,
                            height: 230, fit: BoxFit.contain),
                      ),
                    const SizedBox(height: 6),
                    Center(
                      child: Text(
                        '$baseW x $baseH px, ${_size(origBytes)}',
                        style: const TextStyle(color: kMute, fontSize: 13),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(children: [
                      _tool(Icons.rotate_left, 'Rotate',
                          () => rot = (rot + 270) % 360),
                      const SizedBox(width: 8),
                      _tool(Icons.rotate_right, 'Rotate',
                          () => rot = (rot + 90) % 360),
                      const SizedBox(width: 8),
                      _tool(Icons.flip, 'Flip', () => flipped = !flipped),
                    ]),
                    TextButton(onPressed: pick, child: const Text('Change photo')),
                  ],
                ]),
                _card('2', 'Choose size', [
                  _seg<Mode>(const {
                    Mode.custom: 'Custom',
                    Mode.target: 'Target KB',
                    Mode.percent: 'Percent',
                    Mode.preset: 'Presets',
                  }, mode, (m) {
                    setState(() {
                      mode = m;
                      if (m == Mode.preset) fit = Fit.crop;
                      if (m == Mode.custom) fit = Fit.stretch;
                    });
                  }),
                  if (mode == Mode.custom) ...[
                    const SizedBox(height: 14),
                    Row(children: [
                      _field(wCtrl, 'Width (px)', _onW),
                      const SizedBox(width: 10),
                      _field(hCtrl, 'Height (px)', _onH),
                    ]),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Keep proportions'),
                      value: lock,
                      onChanged: (v) => setState(() => lock = v),
                    ),
                  ],
                  if (mode == Mode.target) ...[
                    _label('Maximum file size'),
                    Wrap(spacing: 8, children: [
                      for (final k in [20, 50, 100, 200, 500, 1000])
                        ActionChip(
                          label: Text(k >= 1000 ? '1 MB' : '$k KB'),
                          onPressed: () => setState(() => kbCtrl.text = '$k'),
                        ),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [_field(kbCtrl, 'Or type KB', null)]),
                  ],
                  if (mode == Mode.percent) ...[
                    _label('Scale: ${percent.round()}%'),
                    Slider(
                      value: percent,
                      min: 10,
                      max: 100,
                      divisions: 18,
                      onChanged: (v) => setState(() => percent = v),
                    ),
                    Wrap(spacing: 8, children: [
                      for (final p in [75, 50, 25])
                        ActionChip(
                          label: Text('$p%'),
                          onPressed: () =>
                              setState(() => percent = p.toDouble()),
                        ),
                    ]),
                  ],
                  if (mode == Mode.preset) ...[
                    _label('Preset'),
                    DropdownButtonFormField<String>(
                      isExpanded: true,
                      value: preset,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      items: [
                        for (final g in presets.entries) ...[
                          DropdownMenuItem<String>(
                            enabled: false,
                            value: '#${g.key}',
                            child: Text(g.key.toUpperCase(),
                                style: const TextStyle(
                                    color: kPri,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ),
                          for (final p in g.value.keys)
                            DropdownMenuItem<String>(
                              value: p,
                              child: Text(p, overflow: TextOverflow.ellipsis),
                            ),
                        ],
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => preset = v);
                      },
                    ),
                  ],
                  if (mode == Mode.preset || mode == Mode.custom) ...[
                    _label('If shape differs'),
                    _seg<Fit>(const {
                      Fit.crop: 'Crop to fill',
                      Fit.fit: 'Fit inside',
                      Fit.stretch: 'Stretch',
                    }, fit, (f) => setState(() => fit = f)),
                    if (fit == Fit.fit)
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Black background'),
                        value: blackBg,
                        onChanged: (v) => setState(() => blackBg = v),
                      ),
                  ],
                ]),
                _card('3', 'Format & quality', [
                  _seg<Fmt>(const {
                    Fmt.jpg: 'JPG',
                    Fmt.png: 'PNG',
                    Fmt.webp: 'WebP',
                    Fmt.pdf: 'PDF',
                  }, fmt, (f) => setState(() => fmt = f)),
                  if (fmt != Fmt.png && mode != Mode.target) ...[
                    _label('Quality: ${quality.round()}%  (lower = smaller file)'),
                    Slider(
                      value: quality,
                      min: 10,
                      max: 100,
                      divisions: 18,
                      onChanged: (v) => setState(() => quality = v),
                    ),
                  ],
                  const SizedBox(height: 6),
                  const Center(
                    child: Text(
                        'Location and camera data are removed automatically.',
                        style: TextStyle(fontSize: 12, color: kMute)),
                  ),
                ]),
                if (result != null)
                  _card('✓', 'Your result', [
                    if (fmt != Fmt.pdf)
                      Center(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.memory(result!,
                              height: 230, fit: BoxFit.contain),
                        ),
                      ),
                    const SizedBox(height: 12),
                    Row(children: [
                      _stat(_size(origBytes), 'Before'),
                      _stat(_size(result!.length), 'After'),
                      _stat('$saved%', 'Saved', c: kOk),
                    ]),
                    const SizedBox(height: 8),
                    Center(
                      child: Text('$resW x $resH px, ${fmt.name.toUpperCase()}',
                          style: const TextStyle(color: kMute, fontSize: 13)),
                    ),
                  ]),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ]),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: kBorder)),
        ),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        child: SafeArea(
          top: false,
          child: Row(children: [
            Expanded(
              child: GestureDetector(
                onTap: busy ? null : (orig == null ? pick : run),
                child: Container(
                  height: 50,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kPri, kPri2]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: busy
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              strokeWidth: 2.5, color: Colors.white))
                      : Text(orig == null ? 'Pick a photo' : 'Resize',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700)),
                ),
              ),
            ),
            if (result != null) ...[
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: share,
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: kChip,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text('Save / Share',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}
