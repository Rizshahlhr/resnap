import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

void main() => runApp(const ResnapApp());

class ResnapApp extends StatelessWidget {
  const ResnapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Resnap',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: const HomePage(),
      );
}

enum Mode { custom, target, percent, preset }

enum Fmt { jpg, png, webp, pdf }

const presets = <String, List<int>>{
  'Instagram Post (1080x1080)': [1080, 1080],
  'Instagram Story (1080x1920)': [1080, 1920],
  'YouTube Thumbnail (1280x720)': [1280, 720],
  'Facebook Cover (820x312)': [820, 312],
  'WhatsApp Profile (500x500)': [500, 500],
  'X / Twitter Post (1600x900)': [1600, 900],
  'LinkedIn Banner (1584x396)': [1584, 396],
};

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final picker = ImagePicker();
  img.Image? source;
  Uint8List? sourceBytes;
  Uint8List? result;
  bool busy = false;

  Mode mode = Mode.custom;
  Fmt fmt = Fmt.jpg;
  bool lockRatio = true;
  double percent = 50;
  String preset = presets.keys.first;
  final wCtrl = TextEditingController();
  final hCtrl = TextEditingController();
  final kbCtrl = TextEditingController(text: '100');

  Future<void> pick() async {
    final f = await picker.pickImage(source: ImageSource.gallery);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      _msg('Could not open this image.');
      return;
    }
    setState(() {
      sourceBytes = bytes;
      source = decoded;
      result = null;
      wCtrl.text = decoded.width.toString();
      hCtrl.text = decoded.height.toString();
    });
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _onW(String v) {
    if (!lockRatio || source == null) return;
    final w = int.tryParse(v);
    if (w == null) return;
    hCtrl.text = (w * source!.height / source!.width).round().toString();
  }

  void _onH(String v) {
    if (!lockRatio || source == null) return;
    final h = int.tryParse(v);
    if (h == null) return;
    wCtrl.text = (h * source!.width / source!.height).round().toString();
  }

  Future<Uint8List> _enc(img.Image im, int q) async {
    switch (fmt) {
      case Fmt.png:
        return Uint8List.fromList(img.encodePng(im));
      case Fmt.jpg:
        return Uint8List.fromList(img.encodeJpg(im, quality: q));
      case Fmt.webp:
        final png = Uint8List.fromList(img.encodePng(im));
        return await FlutterImageCompress.compressWithList(
          png,
          format: CompressFormat.webp,
          quality: q,
          minWidth: im.width,
          minHeight: im.height,
        );
      case Fmt.pdf:
        final jpg = Uint8List.fromList(img.encodeJpg(im, quality: q));
        final doc = pw.Document();
        final page = PdfPageFormat(
            im.width.toDouble(), im.height.toDouble(),
            marginAll: 0);
        doc.addPage(pw.Page(
          pageFormat: page,
          build: (_) => pw.Image(pw.MemoryImage(jpg), fit: pw.BoxFit.fill),
        ));
        return await doc.save();
    }
  }

  Future<Uint8List> _encode(img.Image im) async {
    if (mode != Mode.target) return _enc(im, 90);
    final limit = (int.tryParse(kbCtrl.text) ?? 100) * 1024;
    var cur = im;
    for (int i = 0; i < 10; i++) {
      int lo = 5, hi = 95;
      Uint8List? best;
      while (lo <= hi) {
        final q = (lo + hi) ~/ 2;
        final b = await _enc(cur, q);
        if (b.length <= limit) {
          best = b;
          lo = q + 1;
        } else {
          hi = q - 1;
        }
      }
      if (best != null) return best;
      cur = img.copyResize(cur, width: (cur.width * 0.85).round());
    }
    return _enc(cur, 5);
  }

  Future<void> run() async {
    if (source == null) {
      _msg('Pick a photo first.');
      return;
    }
    setState(() => busy = true);
    try {
      final s = source!;
      int w = s.width, h = s.height;
      if (mode == Mode.custom) {
        w = int.tryParse(wCtrl.text) ?? w;
        h = int.tryParse(hCtrl.text) ?? h;
      } else if (mode == Mode.percent) {
        w = (s.width * percent / 100).round();
        h = (s.height * percent / 100).round();
      } else if (mode == Mode.preset) {
        w = presets[preset]![0];
        h = presets[preset]![1];
      }
      if (w < 1 || h < 1) throw 'Invalid size';
      final resized = (w == s.width && h == s.height)
          ? s
          : img.copyResize(s,
              width: w,
              height: h,
              interpolation: img.Interpolation.average);
      final out = await _encode(resized);
      setState(() => result = out);
    } catch (e) {
      _msg('Something went wrong. Try a different size.');
    } finally {
      setState(() => busy = false);
    }
  }

  Future<void> share() async {
    if (result == null) return;
    final dir = await getTemporaryDirectory();
    final ext = fmt.name;
    final file = File(
        '${dir.path}/resnap_${DateTime.now().millisecondsSinceEpoch}.$ext');
    await file.writeAsBytes(result!);
    await Share.shareXFiles([XFile(file.path)]);
  }

  String _size(int bytes) => bytes > 1024 * 1024
      ? '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB'
      : '${(bytes / 1024).toStringAsFixed(0)} KB';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Resnap')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FilledButton.icon(
            onPressed: pick,
            icon: const Icon(Icons.photo_library),
            label: Text(source == null ? 'Pick a photo' : 'Change photo'),
          ),
          if (sourceBytes != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.memory(sourceBytes!, height: 200, fit: BoxFit.contain),
            ),
            const SizedBox(height: 4),
            Text(
              'Original: ${source!.width} x ${source!.height}, ${_size(sourceBytes!.length)}',
              textAlign: TextAlign.center,
            ),
          ],
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: [
              for (final m in Mode.values)
                ChoiceChip(
                  label: Text(const {
                    Mode.custom: 'Custom size',
                    Mode.target: 'Target KB',
                    Mode.percent: 'Percentage',
                    Mode.preset: 'Social presets',
                  }[m]!),
                  selected: mode == m,
                  onSelected: (_) => setState(() => mode = m),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (mode == Mode.custom) ...[
            Row(children: [
              Expanded(
                child: TextField(
                  controller: wCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Width (px)', border: OutlineInputBorder()),
                  onChanged: _onW,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: hCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Height (px)', border: OutlineInputBorder()),
                  onChanged: _onH,
                ),
              ),
            ]),
            SwitchListTile(
              title: const Text('Keep proportions'),
              value: lockRatio,
              onChanged: (v) => setState(() => lockRatio = v),
            ),
          ],
          if (mode == Mode.target) ...[
            Wrap(spacing: 8, children: [
              for (final k in [20, 50, 100, 200, 500, 1000])
                ActionChip(
                  label: Text(k >= 1000 ? '1 MB' : '$k KB'),
                  onPressed: () => setState(() => kbCtrl.text = '$k'),
                ),
            ]),
            const SizedBox(height: 8),
            TextField(
              controller: kbCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Maximum size (KB)',
                  border: OutlineInputBorder()),
            ),
          ],
          if (mode == Mode.percent) ...[
            Text('Scale: ${percent.round()}%'),
            Slider(
              value: percent,
              min: 10,
              max: 100,
              divisions: 18,
              onChanged: (v) => setState(() => percent = v),
            ),
          ],
          if (mode == Mode.preset)
            DropdownButtonFormField<String>(
              value: preset,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              items: [
                for (final p in presets.keys)
                  DropdownMenuItem(value: p, child: Text(p))
              ],
              onChanged: (v) => setState(() => preset = v!),
            ),
          const SizedBox(height: 16),
          const Text('Save as'),
          const SizedBox(height: 4),
          SegmentedButton<Fmt>(
            segments: [
              for (final f in Fmt.values)
                ButtonSegment(value: f, label: Text(f.name.toUpperCase()))
            ],
            selected: {fmt},
            onSelectionChanged: (s) => setState(() => fmt = s.first),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: busy ? null : run,
            child: busy
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Resize'),
          ),
          if (result != null) ...[
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  Text('Done! New size: ${_size(result!.length)}',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: share,
                    icon: const Icon(Icons.ios_share),
                    label: const Text('Save / Share'),
                  ),
                ]),
              ),
            ),
          ],
          // Ad banner goes here later (AdMob).
        ],
      ),
    );
  }
}
